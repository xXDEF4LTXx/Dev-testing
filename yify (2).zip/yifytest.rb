require_relative 'yify.rb'
require'colorize'
require'json'
#############SEARCH_MOVIE####################
print"Enter the movie you want to search:"
movie='checkmate'
#search = Yify.Search(movie)
#puts search
#############DOWNLOAD_MOVIE##################
#download= Yify.Download(movie)
#puts download
#############SUGGESTED_MOVIE#################
suggested=Yify.Suggestion(movie)
puts suggested