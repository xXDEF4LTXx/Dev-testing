require_relative 'yify.rb'
require'colorize'
require'json'
#############SEARCH_MOVIE####################
print"Enter the movie you want to search:".green
movie=gets.chomp
#begin
#rescue
download= Yify.Download(movie)
#movie doesn't exist
puts"Downloading #{movie}...."

puts""
puts""
puts download
puts"#{movie} has finished downloading"